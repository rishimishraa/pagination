class Stopwatch {
    constructor() {
        this.time = 0;
        this.interval = null;
        this.running = false;
        
        // Get DOM elements
        this.display = document.getElementById('display');
        this.startStopBtn = document.getElementById('startStopBtn');
        this.restartBtn = document.getElementById('restartBtn');
        
        // Bind event listeners
        this.startStopBtn.addEventListener('click', () => this.startStop());
        this.restartBtn.addEventListener('click', () => this.restart());
        
        // Initialize display
        this.updateDisplay();
    }
    
    startStop() {
        if (this.running) {
            this.stop();
        } else {
            this.start();
        }
    }
    
    start() {
        this.running = true;
        this.startStopBtn.textContent = 'Stop';
        this.startStopBtn.className = 'btn stop';
        
        this.interval = setInterval(() => {
            this.time += 10; // Increment by 10ms for smoother display
            this.updateDisplay();
        }, 10);
    }
    
    stop() {
        this.running = false;
        this.startStopBtn.textContent = 'Start';
        this.startStopBtn.className = 'btn start';
        
        if (this.interval) {
            clearInterval(this.interval);
            this.interval = null;
        }
    }
    
    restart() {
        this.stop();
        this.time = 0;
        this.updateDisplay();
    }
    
    updateDisplay() {
        const minutes = Math.floor(this.time / 60000);
        const seconds = Math.floor((this.time % 60000) / 1000);
        const centiseconds = Math.floor((this.time % 1000) / 10);
        
        const formattedTime = 
            `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}:${centiseconds.toString().padStart(2, '0')}`;
        
        this.display.textContent = formattedTime;
    }
}

// Initialize the stopwatch when the page loads
document.addEventListener('DOMContentLoaded', () => {
    new Stopwatch();
});

// Add keyboard shortcuts
document.addEventListener('keydown', (event) => {
    if (event.code === 'Space') {
        event.preventDefault();
        document.getElementById('startStopBtn').click();
    } else if (event.code === 'KeyR') {
        event.preventDefault();
        document.getElementById('restartBtn').click();
    }
});